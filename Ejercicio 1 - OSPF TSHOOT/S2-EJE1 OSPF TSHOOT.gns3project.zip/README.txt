CCNP ENARSI
Curso: OSPF & OSPFv3
Ejercicio: Configuración OSPFv3 Tradicional 
Firmware: Routers  -> c7200-advipservicesk9-mz.152-4.S5.bin
Autor: Jose Tomas Lopez